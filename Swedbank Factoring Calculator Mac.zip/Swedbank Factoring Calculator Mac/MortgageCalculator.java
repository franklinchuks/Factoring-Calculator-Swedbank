import java.util.Scanner;

import java.text.NumberFormat;

public class FactoringCalculator {

    private static final int PERCENTAGE_DIVISION = 100;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Invoice amount: ");
        double invoiceAmount = scanner.nextDouble();

        System.out.println("Advance rate: ");
        float advanceRate = scanner.nextFloat() / PERCENTAGE_DIVISION;

        System.out.println("Interest rate: ");
        float interestRate = scanner.nextFloat() / PERCENTAGE_DIVISION;

        System.out.println("Payment term: ");
        int paymentTerm = scanner.nextInt();

        System.out.println("Commission fee: ");
        float commFee = scanner.nextFloat() / PERCENTAGE_DIVISION;

        System.out.println(NumberFormat.getCurrencyInstance().format(invoiceAmount));
        System.out.println(advanceRate);
        System.out.println(interestRate);
        System.out.println(paymentTerm);
        System.out.println(commFee);


        /*
        System.out.println("Invoice financing expenses: ");
        System.out.println(percentOfInvoice + "%");
        System.out.println(NumberFormat.getCurrencyInstance().format(cost));
         */

    }
}
